# Vaibhav Pharmacy: DSR Auto-Generator Setup Guide

## What This Does

Your pharmacist continues billing in Marg as usual. At end of day, they export the day's sales from Marg and upload the file to a Google Drive folder. The script automatically:

1. Picks up the XLS/DBF/CSV file
2. Parses Marg's bill-based format (bill headers, item detail lines, quantities in strips:loose)
3. Auto-classifies items as MEDICINE or OTHER
4. Calculates per-item amounts from MRP and quantity
5. Routes data to the correct monthly tab (DSR_Mar26, DSR_Apr26...)
6. Adds BATCH, EXPIRY, and BILL_TOTAL as bonus columns
7. Applies color formatting and archives the processed file
8. Skips already-imported bills (safe to re-upload)

Pharmacist effort: ~30 seconds (export from Marg + upload to Drive).

---

## How Marg's Export Works (What the Script Reads)

Your Marg file (tested with 17032026.xls / 17032026.dbf) has this structure:

```
Row 0: Date ("17-03-2026") in BILLNO column
Bill header: BILLNO=0000337, DESCRIPTIO=CASH, GROSSAMT/DISCOUNT/TAX/NETAMT
Item lines: DESCRIPTIO="1  1 TELMIKIND AMH TAB  1*10", DR="1:0", GROSSAMT="107.77 10/27"
Empty row (separator)
... next bill ...
DAY TOTAL / GRAND TOTAL at end
```

The script handles all of this. You don't need to change Marg's export format.

---

## Step 1: How to Export from Marg (Daily Routine)

Your pharmacist does ONE of these at closing:

### Option A: Multi Bill Export (Recommended)
1. Go to **Daily Reports > Daily Working > Multi Bill/Other Printing**
2. Type = **Sale**
3. Date = **today**
4. Click **Accept**
5. Press ***** (Asterisk) to select all entries
6. Press **F6** > **Save Soft Copy**
7. Save as XLS to Desktop (or a known folder)

### Option B: If Marg Produces a DBF
The script handles .dbf files too. Same upload process.

### Then: Upload to Google Drive
- Upload the file to the **Marg_Imports** folder on Google Drive
- Phone: use Google Drive app to upload directly
- Desktop: drag and drop into the Drive folder in browser

---

## Step 2: Google Drive Folders (One-time)

### 2.1 Create "Marg_Imports" Folder
1. Open Google Drive > New > Folder > name it **Marg_Imports**
2. Open the folder. Copy the folder ID from the URL bar:
   `https://drive.google.com/drive/folders/`**COPY_THIS_ID**

### 2.2 Create "Marg_Archive" Folder
1. Create another folder called **Marg_Archive**
2. Copy its ID the same way

### 2.3 Get Your DSR Sheet ID
1. Open your existing DSR Google Sheet
2. Copy the ID from the URL:
   `https://docs.google.com/spreadsheets/d/`**COPY_THIS_ID**`/edit`

You now have 3 IDs. Keep them handy.

---

## Step 3: Install the Script (One-time)

### 3.1 Open the Script Editor
1. Open your DSR Google Sheet
2. Go to **Extensions > Apps Script**

### 3.2 Paste the Code
1. Delete everything in the editor
2. Copy the entire contents of **Code.gs** and paste it in

### 3.3 Fill in CONFIG (top of the script)
Replace the placeholder values:

```javascript
DSR_SHEET_ID: "paste_your_sheet_id",
IMPORT_FOLDER_ID: "paste_marg_imports_folder_id",
ARCHIVE_FOLDER_ID: "paste_marg_archive_folder_id",
NOTIFY_EMAIL: "your@email.com",
```

### 3.4 Enable Drive API
1. In the left panel of Apps Script editor, click **+** next to **Services**
2. Find **Drive API** (v2) and click **Add**
3. This is required for reading XLS/DBF files

### 3.5 Save
Press **Ctrl+S**. Name the project "DSR Auto-Generator".

---

## Step 4: Test

### 4.1 Upload your sample file
Upload the `17032026.xls` (or `17032026.dbf`) to the Marg_Imports folder.

### 4.2 Run the script
1. In Apps Script editor, select **runNow** from the function dropdown
2. Click **Run**
3. First time: Google will ask for permissions. Click through:
   - "Review Permissions"
   - Select your Google account
   - "Advanced" > "Go to DSR Auto-Generator (unsafe)" > "Allow"
   (This warning is normal for personal scripts)

### 4.3 Verify
- Check your DSR Sheet: a new tab **DSR_Mar26** should have 13 rows
- Check Marg_Archive: the uploaded file should have moved there
- Check Execution Log in Apps Script for details

### Expected output from 17032026.xls:
| DATE | BILL_NO | CATEGORY | ITEM | QTY | UNIT | AMOUNT |
|------|---------|----------|------|-----|------|--------|
| Tue, Mar 17, 2026 | 0000337 | MEDICINE | TELMIKIND AMH TAB | 1 | STRIP | ₹ 108 |
| Tue, Mar 17, 2026 | 0000338 | MEDICINE | SARIDON TAB | 1 | TAB | ₹ 6 |
| Tue, Mar 17, 2026 | 0000344 | OTHER | HAZMOLA CANDY 130PCS | 2 | PCS | ₹ 243 |
| ... 10 more rows ... |

---

## Step 5: Set Up Automation (One-time)

Pick one:

**Daily at 9 PM (recommended):**
Select **createDailyTrigger** > Run

**Every 30 minutes:**
Select **createTrigger** > Run

After this, the script runs automatically. Your pharmacist just uploads the file.

---

## DSR Columns Explained

| Column | Source | Notes |
|--------|--------|-------|
| DATE | Marg file header | Formatted as "Tue, Mar 17, 2026" |
| BILL_NO | Marg bill number | Used for duplicate detection |
| CATEGORY | Auto-classified | MEDICINE or OTHER based on keywords |
| ITEM | Marg item name | As entered in Marg |
| QUANTITY | Parsed from strips:loose | Converts to pieces for loose sales |
| UNIT | Inferred | STRIP (full strips), TAB (loose tablets), PCS (packets/pieces) |
| AMOUNT | Calculated | MRP-based: strips x MRP + loose x (MRP/pack_size) |
| DISCOUNT | Bill-level discount | From Marg's bill header |
| MODE | Payment mode | Cash, UPI, Card, Credit |
| BATCH | Batch number | From Marg item line |
| EXPIRY | Expiry date | Format: MM/YY from Marg |
| BILL_TOTAL | Bill net amount | After discount and tax |

---

## Customization

### Fixing Misclassified Items
If a medicine shows as OTHER, add a keyword to MEDICINE_KEYWORDS:
```javascript
"new_medicine_name",
```

If an FMCG item shows as MEDICINE (e.g., a product with "tab" in the name), add it to FMCG_KEYWORDS:
```javascript
"product name",
```

### Adding UPI/Card Detection
Marg labels payment mode in the DESCRIPTIO column of the bill header. If your bills show "UPI", "CARD", "CREDIT" etc., the script will detect them automatically. Your sample file had all CASH sales. Once you have a day with mixed payments, verify the detection.

---

## Troubleshooting

**"No bills found in file":** The file format may differ from the tested export. Check that you're using Multi Bill export (Daily Reports > Daily Working).

**Duplicate rows appearing:** This shouldn't happen because the script checks BILL_NO before inserting. If it does, the bill numbers may have changed between exports.

**File stuck in Marg_Imports (not processed):** Check the file extension. Only .xls, .xlsx, .csv, .dbf are processed. Also check the Execution Log in Apps Script for error details.

**Permission denied on Drive API:** Make sure you added the Drive API service in step 3.4.

---

## What Comes Next (Phase 2)

Once this runs for 2-4 weeks and you have clean automated data:

1. **Demand velocity per SKU:** rolling 7-day and 30-day averages
2. **Expiry risk alerts:** cross-reference EXPIRY column with sales velocity
3. **Daily WhatsApp summary:** auto-send yesterday's numbers to you
4. **Reorder triggers:** flag items below safety stock
5. **Category margin analysis:** Medicine vs FMCG profitability

All built on the same data pipe you're setting up now.
