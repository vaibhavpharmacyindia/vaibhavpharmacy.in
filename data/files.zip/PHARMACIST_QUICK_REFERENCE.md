# End of Day: Marg Export (Quick Reference)

Keep this near the billing computer.

---

## Step 1: Export Today's Bills
- Open Marg
- Go to: **Daily Reports > Daily Working > Multi Bill/Other Printing**
- Type = **Sale**
- Date = **Today**
- Click **Accept**
- Press ***** key to select all
- Press **F6** > **Save Soft Copy**
- Save to Desktop

## Step 2: Upload to Google Drive
- Open Google Drive (browser or phone app)
- Go to **Marg_Imports** folder
- Upload the saved file

## Done!
DSR sheet updates automatically. No manual entry needed.

---

## If Something Goes Wrong
- The file stays in Marg_Imports until successfully processed
- You can re-upload the same file safely (duplicates are skipped)
- Call Vaibhav if the DSR sheet is not updating
