// ============================================================
// VAIBHAV PHARMACY : DSR AUTO-GENERATOR FROM MARG EXPORTS
// ============================================================
//
// Marg's "Multi Bill" export has a specific layout:
//   Row 0: Date in BILLNO column ("17-03-2026")
//   Bill header rows: BILLNO=number, DESCRIPTIO=payment mode,
//     GROSSAMT/DISCOUNT/TAX/NETAMT/CASH = bill-level financials
//   Item detail rows: DESCRIPTIO="serial code ITEM_NAME packing",
//     DR="strips:loose" or just a number, GROSSAMT="MRP expiry",
//     DISCOUNT=batch number
//   Empty rows between bills
//   DAY TOTAL / GRAND TOTAL at end
//
// This script parses that format and writes to your DSR sheet.
// ============================================================


// ======================== CONFIG ========================
const CONFIG = {
  DSR_SHEET_ID: "YOUR_DSR_SHEET_ID_HERE",
  IMPORT_FOLDER_ID: "YOUR_IMPORT_FOLDER_ID_HERE",
  ARCHIVE_FOLDER_ID: "YOUR_ARCHIVE_FOLDER_ID_HERE",
  NOTIFY_EMAIL: "YOUR_EMAIL_HERE",
  TAB_PREFIX: "DSR_",
  MONTH_NAMES: ["Jan","Feb","Mar","Apr","May","Jun",
                "Jul","Aug","Sep","Oct","Nov","Dec"],
};


// ======================== CLASSIFICATION ========================
// Lowercase substrings. If item name contains any of these: MEDICINE.
// FMCG list is checked first: if matched, it's OTHER regardless.

const FMCG_KEYWORDS = [
  "hazmola", "hajmola", "candy", "dairy milk", "kitkat", "munch",
  "lays", "kurkure", "biscuit", "chocolate", "chips",
  "water bottle", "soft drink", "juice", "milk ",
  "bread", "butter", "maggi", "noodle",
  "condom", "diaper", "sanitary", "tissue", "cotton",
];

const MEDICINE_KEYWORDS = [
  // From your actual 17-Mar-2026 data
  "telmikind", "saridon", "ajubi", "dolo", "calpol", "pantop",
  "nicip", "cyra", "endcort", "jencal", "sterferol",
  // Dosage forms (strongest signals)
  " tab", " cap", " syp", " inj", " oint", " cream",
  " gel", " drop", " susp", " sachet", " lotion",
  " spray", " inhaler", " strip",
  // Common Indian pharmacy brands/generics
  "azithro", "amox", "cefix", "cipro", "metro", "para",
  "ibupr", "diclo", "omepra", "panto", "rabepra", "montel",
  "levocet", "allegra", "cetiri", "montimed", "pudin",
  "azikem", "novamox", "combiflam", "augment", "monocef",
  "oflox", "norflox", "aceclo", "domper", "ondanse",
  "ranitid", "antacid", "digene", "gelusil", "disprin",
  "vicks", "strepsils", "betadine", "volini", "moov",
  "benadryl", "alex", "grilinctus", "ascoril",
  "shelcal", "becosule", "revital", "supradyn", "limcee",
  "sinarest", "cetrizine", "levocetirizine", "montelukast",
  "atorva", "ecosprin", "metformin", "glimep", "telma",
  "amlod", "losartan", "olmesartan", "torsemide",
  "crocin", "zandu", "eno ",
];

const MODE_MAP = {
  "cash": "Cash", "upi": "UPI", "card": "Card",
  "credit": "Credit", "online": "UPI",
  "g-pay": "UPI", "gpay": "UPI",
  "phonepe": "UPI", "paytm": "UPI",
};


// ======================== MAIN ========================

function processNewMargExports() {
  const importFolder = DriveApp.getFolderById(CONFIG.IMPORT_FOLDER_ID);
  const archiveFolder = DriveApp.getFolderById(CONFIG.ARCHIVE_FOLDER_ID);
  
  let processedCount = 0;
  let errorFiles = [];

  // Process all files in the import folder
  const allFiles = importFolder.getFiles();
  while (allFiles.hasNext()) {
    const file = allFiles.next();
    const name = file.getName().toLowerCase();
    
    // Only process xls, xlsx, csv, dbf files
    if (!name.match(/\.(xls|xlsx|csv|dbf)$/)) continue;
    
    try {
      Logger.log("Processing: " + file.getName());
      const result = processFile(file);
      file.moveTo(archiveFolder);
      processedCount++;
      Logger.log("OK: " + file.getName() + 
                 " | " + result.rowCount + " items | " +
                 result.billCount + " bills | Tab: " + result.tabName);
    } catch (e) {
      errorFiles.push(file.getName() + ": " + e.message);
      Logger.log("ERROR: " + file.getName() + ": " + e.message);
    }
  }

  if (errorFiles.length > 0 && CONFIG.NOTIFY_EMAIL !== "YOUR_EMAIL_HERE") {
    MailApp.sendEmail(
      CONFIG.NOTIFY_EMAIL,
      "DSR Import: " + errorFiles.length + " file(s) failed",
      "Errors:\n\n" + errorFiles.join("\n\n")
    );
  }
  
  Logger.log("Done. Processed: " + processedCount + ", Errors: " + errorFiles.length);
}


function processFile(file) {
  const name = file.getName().toLowerCase();
  let data;

  if (name.endsWith(".csv")) {
    const content = file.getBlob().getDataAsString();
    data = Utilities.parseCsv(content);
  } else {
    // For xls/xlsx/dbf: convert to Google Sheet, read, delete temp
    const tempId = convertToGoogleSheet_(file);
    try {
      const tempSS = SpreadsheetApp.openById(tempId);
      data = tempSS.getSheets()[0].getDataRange().getValues();
      // Convert all values to strings (matching CSV behavior)
      data = data.map(function(row) {
        return row.map(function(cell) { return String(cell); });
      });
    } finally {
      DriveApp.getFileById(tempId).setTrashed(true);
    }
  }

  if (!data || data.length < 2) throw new Error("File has no data");
  
  return parseMargAndWrite(data);
}


function convertToGoogleSheet_(file) {
  var blob = file.getBlob();
  var resource = {
    title: "[TEMP_DSR] " + file.getName(),
    mimeType: MimeType.GOOGLE_SHEETS
  };
  var created = Drive.Files.insert(resource, blob, { convert: true });
  return created.id;
}


// ======================== MARG PARSER ========================

function parseMargAndWrite(data) {
  var exportDate = null;
  var bills = [];
  var currentBill = null;

  for (var i = 0; i < data.length; i++) {
    var row = data[i];
    var billno     = String(row[0] || "").trim();
    var descriptio = String(row[1] || "").trim();
    var dr         = String(row[2] || "").trim();
    var grossamt   = String(row[3] || "").trim();
    var discount   = String(row[4] || "").trim();
    var tax        = String(row[5] || "").trim();
    var netamt     = String(row[7] || "").trim();
    var cash       = String(row[8] || "").trim();

    // Skip empty rows
    if (!billno && !descriptio && !dr && !grossamt) continue;

    // Skip summary rows
    if (dr.indexOf("DAY TOTAL") !== -1 || dr.indexOf("GRAND TOTAL") !== -1) continue;
    if (billno.indexOf("Total No") !== -1) continue;

    // Date row: only billno is populated, looks like a date
    if (!exportDate && billno && !descriptio && !dr && !grossamt) {
      var d = parseMargDate_(billno);
      if (d) {
        exportDate = d;
        continue;
      }
    }

    // Bill header: billno is a numeric string like "0000337"
    if (billno.match(/^\d{4,}$/)) {
      if (currentBill && currentBill.items.length > 0) {
        bills.push(currentBill);
      }

      var paymentMode = "Cash";
      var modeRaw = descriptio.toLowerCase();
      for (var key in MODE_MAP) {
        if (modeRaw.indexOf(key) !== -1) {
          paymentMode = MODE_MAP[key];
          break;
        }
      }

      // Check if "#" is present in DR column (Marg uses this to flag something)
      var hasHash = dr.indexOf("#") !== -1;

      currentBill = {
        billNo: billno,
        date: exportDate || new Date(),
        paymentMode: paymentMode,
        grossAmt: parseNum_(grossamt),
        discount: parseNum_(discount),
        tax: parseNum_(tax),
        netAmt: parseNum_(netamt),
        cashAmt: parseNum_(cash),
        items: [],
      };
      continue;
    }

    // Item detail: no billno, descriptio has item info
    if (!billno && descriptio && currentBill) {
      var item = parseItemLine_(descriptio, dr, grossamt, discount);
      if (item) {
        currentBill.items.push(item);
      }
    }
  }

  // Last bill
  if (currentBill && currentBill.items.length > 0) {
    bills.push(currentBill);
  }

  if (bills.length === 0) throw new Error("No bills found in file");

  Logger.log("Parsed " + bills.length + " bills, date: " + exportDate);

  // Write to DSR
  return writeToDSR_(exportDate || new Date(), bills);
}


/**
 * Parse an item detail line from Marg.
 * DESCRIPTIO: "1   1 TELMIKIND AMH TAB    1*10"
 *              ^ser ^code ^item_name        ^packing
 * DR: "1:0" (strips:loose) or "2" (whole units)
 * GROSSAMT: "107.77 10/27" (MRP + expiry) or "121.49" (MRP only)
 * DISCOUNT column: batch number (e.g., "C95Y023")
 */
function parseItemLine_(descriptio, dr, grossamt, discountCol) {
  // Match: serial(1+ digits), spaces, code(1+ digits), spaces, name, spaces, packing
  var match = descriptio.match(/^(\d+)\s+(\d+)\s+(.+?)\s{2,}(\d+[\*xX]\S+)\s*$/);
  if (!match) {
    // Try with single space before packing (some items have long names)
    match = descriptio.match(/^(\d+)\s+(\d+)\s+(.+?)\s+(\d+[\*xX]\S+)\s*$/);
  }
  if (!match) return null;

  var itemName = match[3].trim();
  var packing = match[4];

  // Parse pack size from packing string
  var packMatch = packing.match(/(\d+)[\*xX](\d+)/);
  var packSize = packMatch ? parseInt(packMatch[2]) : 1;

  // Parse quantity
  var qty = parseQuantity_(dr.trim(), packSize);

  // Parse MRP and expiry
  var mrpData = parseMRPExpiry_(grossamt.trim());

  // Classify
  var category = classifyItem_(itemName);

  // Calculate selling price per item for the DSR
  // For multi-item bills, we approximate from MRP and quantity
  var itemAmount = 0;
  if (qty.strips > 0 || qty.loose > 0) {
    var perPiece = packSize > 0 ? mrpData.mrp / packSize : mrpData.mrp;
    itemAmount = (qty.strips * mrpData.mrp) + (qty.loose * perPiece);
  } else {
    itemAmount = mrpData.mrp * qty.totalPieces;
  }

  return {
    name: itemName,
    packing: packing,
    quantity: qty.displayQty,
    unit: qty.unit,
    mrp: mrpData.mrp,
    expiry: mrpData.expiry,
    batch: discountCol || "",
    category: category,
    amount: Math.round(itemAmount * 100) / 100,
  };
}


function parseQuantity_(drStr, packSize) {
  // strips:loose format (e.g., "1:0", "0:5")
  var slMatch = drStr.match(/^(\d+):(\d+)$/);
  if (slMatch) {
    var strips = parseInt(slMatch[1]);
    var loose = parseInt(slMatch[2]);
    var totalPieces = (strips * packSize) + loose;
    
    if (strips > 0 && loose === 0) {
      return { strips: strips, loose: 0, totalPieces: totalPieces,
               displayQty: strips, unit: "STRIP" };
    }
    return { strips: strips, loose: loose, totalPieces: totalPieces,
             displayQty: totalPieces, unit: "TAB" };
  }

  // Plain number (whole packs/pieces)
  var num = parseInt(drStr);
  if (!isNaN(num)) {
    return { strips: 0, loose: 0, totalPieces: num,
             displayQty: num, unit: "PCS" };
  }

  return { strips: 0, loose: 0, totalPieces: 1,
           displayQty: 1, unit: "PCS" };
}


function parseMRPExpiry_(str) {
  // "107.77 10/27" or "107.77  10/27"
  var match = str.match(/^([\d.]+)\s+(\d{1,2}\/\d{2,4})$/);
  if (match) return { mrp: parseFloat(match[1]), expiry: match[2] };

  // Just MRP
  var num = parseFloat(str);
  if (!isNaN(num)) return { mrp: num, expiry: "" };

  return { mrp: 0, expiry: "" };
}


function classifyItem_(itemName) {
  var lower = " " + itemName.toLowerCase() + " ";
  
  // Check FMCG first (these override medicine keywords)
  for (var i = 0; i < FMCG_KEYWORDS.length; i++) {
    if (lower.indexOf(FMCG_KEYWORDS[i]) !== -1) return "OTHER";
  }

  // Check medicine keywords
  for (var i = 0; i < MEDICINE_KEYWORDS.length; i++) {
    if (lower.indexOf(MEDICINE_KEYWORDS[i]) !== -1) return "MEDICINE";
  }

  return "OTHER";
}


function parseMargDate_(str) {
  // DD-MM-YYYY
  var m = str.match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/);
  if (m) return new Date(parseInt(m[3]), parseInt(m[2]) - 1, parseInt(m[1]));
  
  // DD/MM/YYYY
  m = str.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) return new Date(parseInt(m[3]), parseInt(m[2]) - 1, parseInt(m[1]));
  
  return null;
}


function parseNum_(str) {
  return parseFloat(str.replace(/[^0-9.\-]/g, "")) || 0;
}


// ======================== DSR WRITER ========================

function writeToDSR_(exportDate, bills) {
  var ss = SpreadsheetApp.openById(CONFIG.DSR_SHEET_ID);
  var tabName = getTabName_(exportDate);
  var sheet = getOrCreateTab_(ss, tabName);

  // Build all DSR rows
  var dsrRows = [];
  for (var b = 0; b < bills.length; b++) {
    var bill = bills[b];
    for (var t = 0; t < bill.items.length; t++) {
      var item = bill.items[t];
      dsrRows.push({
        date: bill.date,
        billNo: bill.billNo,
        customer: "",  // Marg cash sales don't have customer names
        category: item.category,
        item: item.name,
        quantity: item.quantity,
        unit: item.unit,
        amount: item.amount,
        billAmount: bill.netAmt,
        discount: bill.discount,
        mode: bill.paymentMode,
        batch: item.batch,
        expiry: item.expiry,
        mrp: item.mrp,
      });
    }
  }

  if (dsrRows.length === 0) throw new Error("No items to write");

  // Check for duplicate bills (avoid re-import)
  var lastRow = sheet.getLastRow();
  var existingBills = {};
  if (lastRow > 1) {
    var existingData = sheet.getRange(2, 2, lastRow - 1, 1).getValues(); // Column B = BILL_NO
    for (var i = 0; i < existingData.length; i++) {
      existingBills[String(existingData[i][0]).trim()] = true;
    }
  }

  // Filter out already-imported bills
  var newRows = [];
  for (var i = 0; i < dsrRows.length; i++) {
    if (!existingBills[dsrRows[i].billNo]) {
      newRows.push(dsrRows[i]);
    }
  }

  if (newRows.length === 0) {
    Logger.log("All bills already imported. Skipping.");
    return { rowCount: 0, billCount: 0, tabName: tabName };
  }

  // Write to sheet
  var startRow = Math.max(sheet.getLastRow(), 1) + 1;
  var values = newRows.map(function(r) {
    var dateStr = Utilities.formatDate(
      r.date, Session.getScriptTimeZone(), "EEE, MMM dd, yyyy"
    );
    return [
      dateStr,        // A: DATE
      r.billNo,       // B: BILL_NO
      r.category,     // C: CATEGORY
      r.item,         // D: ITEM
      r.quantity,     // E: QUANTITY
      r.unit,         // F: UNIT
      "₹ " + r.amount.toFixed(0), // G: AMOUNT (item MRP-based)
      r.discount > 0 ? "₹ " + r.discount.toFixed(0) : "",  // H: DISCOUNT (bill level)
      r.mode,         // I: MODE
      r.batch,        // J: BATCH
      r.expiry,       // K: EXPIRY
      "₹ " + r.billAmount.toFixed(0), // L: BILL_TOTAL
    ];
  });

  sheet.getRange(startRow, 1, values.length, 12).setValues(values);

  // Apply formatting
  for (var i = 0; i < newRows.length; i++) {
    var rowNum = startRow + i;
    var catCell = sheet.getRange(rowNum, 3);
    var modeCell = sheet.getRange(rowNum, 9);

    if (newRows[i].category === "MEDICINE") {
      catCell.setBackground("#a8d8b9").setFontColor("#1a5c2e");
    } else {
      catCell.setBackground("#b8d4e8").setFontColor("#1a3d5c");
    }

    if (newRows[i].mode === "Cash") {
      modeCell.setBackground("#fde8c8").setFontColor("#7a4a0a");
    } else if (newRows[i].mode === "UPI") {
      modeCell.setBackground("#c8f0c8").setFontColor("#1a5c2e");
    }
  }

  // Count unique bills
  var billSet = {};
  for (var i = 0; i < newRows.length; i++) billSet[newRows[i].billNo] = true;
  var billCount = Object.keys(billSet).length;

  Logger.log("Wrote " + newRows.length + " items from " + billCount + " bills to " + tabName);
  return { rowCount: newRows.length, billCount: billCount, tabName: tabName };
}


function getTabName_(date) {
  var month = CONFIG.MONTH_NAMES[date.getMonth()];
  var year = String(date.getFullYear()).slice(-2);
  return CONFIG.TAB_PREFIX + month + year;
}


function getOrCreateTab_(ss, tabName) {
  var sheet = ss.getSheetByName(tabName);
  if (sheet) return sheet;

  sheet = ss.insertSheet(tabName);

  // Headers matching your DSR format + extra columns from Marg
  var headers = [
    "DATE", "BILL_NO", "CATEGORY", "ITEM", "QUANTITY", "UNIT",
    "AMOUNT", "DISCOUNT", "MODE", "BATCH", "EXPIRY", "BILL_TOTAL"
  ];
  sheet.getRange(1, 1, 1, headers.length).setValues([headers]);

  // Style header
  var hdr = sheet.getRange(1, 1, 1, headers.length);
  hdr.setFontWeight("bold");
  hdr.setBackground("#2d5a27");
  hdr.setFontColor("white");
  hdr.setFontFamily("Arial");

  // Column widths
  var widths = [150, 90, 100, 220, 80, 60, 90, 80, 70, 110, 70, 90];
  for (var i = 0; i < widths.length; i++) {
    sheet.setColumnWidth(i + 1, widths[i]);
  }

  sheet.setFrozenRows(1);
  Logger.log("Created tab: " + tabName);
  return sheet;
}


// ======================== TRIGGERS ========================

function createTrigger() {
  removeTriggers_("processNewMargExports");
  ScriptApp.newTrigger("processNewMargExports")
    .timeBased().everyMinutes(30).create();
  Logger.log("Trigger: every 30 minutes");
}

function createDailyTrigger() {
  removeTriggers_("processNewMargExports");
  ScriptApp.newTrigger("processNewMargExports")
    .timeBased().atHour(21).everyDays(1)
    .inTimezone("Asia/Kolkata").create();
  Logger.log("Trigger: daily at 9 PM IST");
}

function removeTriggers_(fnName) {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === fnName) {
      ScriptApp.deleteTrigger(triggers[i]);
    }
  }
}

function removeAllTriggers() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    ScriptApp.deleteTrigger(triggers[i]);
  }
  Logger.log("All triggers removed.");
}


// ======================== UTILITIES ========================

/** Run manually to process files immediately */
function runNow() {
  processNewMargExports();
}

/** Test: peek at a file in the import folder to verify parsing */
function testParsing() {
  var folder = DriveApp.getFolderById(CONFIG.IMPORT_FOLDER_ID);
  var files = folder.getFiles();
  if (!files.hasNext()) {
    Logger.log("No files in import folder.");
    return;
  }

  var file = files.next();
  Logger.log("Testing: " + file.getName());

  var tempId = convertToGoogleSheet_(file);
  try {
    var tempSS = SpreadsheetApp.openById(tempId);
    var data = tempSS.getSheets()[0].getDataRange().getValues();
    data = data.map(function(row) {
      return row.map(function(cell) { return String(cell); });
    });

    Logger.log("Rows: " + data.length);
    Logger.log("Columns: " + data[0].length);
    Logger.log("\nFirst 5 rows:");
    for (var i = 0; i < Math.min(5, data.length); i++) {
      Logger.log("  " + data[i].join(" | "));
    }

    // Try full parse (dry run)
    var exportDate = null;
    var bills = [];
    var currentBill = null;
    // (reuse the parsing logic from parseMargAndWrite but just log)

    Logger.log("\n=== Attempting full parse ===");
    // just call parseMargAndWrite logic without writing
    // For real test, run runNow() instead

  } finally {
    DriveApp.getFileById(tempId).setTrashed(true);
  }
}


/** Daily summary of sales */
function todaySummary() {
  var ss = SpreadsheetApp.openById(CONFIG.DSR_SHEET_ID);
  var today = new Date();
  var tabName = getTabName_(today);
  var sheet = ss.getSheetByName(tabName);
  if (!sheet) { Logger.log("No tab: " + tabName); return; }

  var data = sheet.getDataRange().getValues();
  var todayStr = Utilities.formatDate(today, Session.getScriptTimeZone(), "EEE, MMM dd, yyyy");

  var totalAmt = 0, medCount = 0, otherCount = 0;
  var cashAmt = 0, upiAmt = 0;
  var billSet = {};

  for (var i = 1; i < data.length; i++) {
    if (String(data[i][0]).indexOf(todayStr.substring(5)) === -1) continue;
    // approximate date match by month+day
    
    var amt = parseFloat(String(data[i][6]).replace(/[₹\s,]/g, "")) || 0;
    totalAmt += amt;
    if (data[i][2] === "MEDICINE") medCount++; else otherCount++;
    if (data[i][8] === "Cash") cashAmt += amt;
    else if (data[i][8] === "UPI") upiAmt += amt;
    billSet[String(data[i][1])] = true;
  }

  var summary =
    "=== DSR SUMMARY: " + todayStr + " ===\n" +
    "Bills: " + Object.keys(billSet).length + "\n" +
    "Items: " + (medCount + otherCount) + " (Medicine: " + medCount + ", Other: " + otherCount + ")\n" +
    "Total: ₹" + totalAmt.toFixed(0) + "\n" +
    "Cash: ₹" + cashAmt.toFixed(0) + " | UPI: ₹" + upiAmt.toFixed(0);

  Logger.log(summary);
  return summary;
}
